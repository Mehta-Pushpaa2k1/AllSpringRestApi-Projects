package com.entity;

public class Office {
}
