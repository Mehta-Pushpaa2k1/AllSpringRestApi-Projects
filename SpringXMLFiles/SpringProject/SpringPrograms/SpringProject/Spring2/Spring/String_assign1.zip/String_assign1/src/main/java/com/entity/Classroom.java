package com.entity;

public class Classroom {

public void tenth(){
    System.out.println("this is 10th class");
}
}
