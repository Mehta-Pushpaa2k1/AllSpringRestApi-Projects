package com.Main;

import com.configuration.Config;
import com.entity.Classroom;
import com.entity.Library;
import com.entity.Student;
import com.entity2.Teacher;
import com.qsp.School;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Result {
    public static void main(String[] args) {
      ApplicationContext context =  new AnnotationConfigApplicationContext(Config.class);

      Student s = (Student) context.getBean("student");
      s.marks();
      System.out.println(s);

        System.out.println();

        School sch =(School) context.getBean("school");
        sch.m1();
        System.out.println(sch.getS_id());
        System.out.println(sch.getS_name());
        System.out.println(sch.getS_address());

      System.out.println();

        Teacher teach=(Teacher) context.getBean("teacher");
        teach.responsibility();
        System.out.println(teach.getT_name());
        System.out.println(teach.getAge());
        System.out.println(teach.getGender());

       Library lib=(Library) context.getBean("library");
       lib.entre();
       lib.books();

    }



}
