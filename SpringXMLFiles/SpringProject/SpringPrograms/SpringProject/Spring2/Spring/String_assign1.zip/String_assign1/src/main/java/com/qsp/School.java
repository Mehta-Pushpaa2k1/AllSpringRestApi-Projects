package com.qsp;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class School {

    private int s_id;
    private String s_name;
    private String s_address;

    public void m1(){
        System.out.println("This is best school");
    }

    public School(){

    }

    public School(int s_id, String s_name, String s_address) {
        this.s_id = s_id;
        this.s_name = s_name;
        this.s_address = s_address;
    }

    public int getS_id() {
        return s_id;
    }

@Value(value = "779")
    public void setS_id(int s_id) {
        this.s_id = s_id;
    }

    public String getS_name() {
        return s_name;
    }

@Value(value = "Mewat model school")
    public void setS_name(String s_name) {
        this.s_name = s_name;
    }

    public String getS_address() {
        return s_address;
    }

@Value(value = "Nuh")
    public void setS_address(String s_address) {
        this.s_address = s_address;
    }
}
