package com.entity;

import org.springframework.beans.factory.annotation.Autowired;

public class Library {
    @Autowired
    Classroom c;

    public void entre(){
        c.tenth();
    }
    
    public void books(){
        System.out.println("Collect books from here");
    }


}
